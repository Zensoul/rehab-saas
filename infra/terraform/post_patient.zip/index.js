// small POST /patients lambda - puts an item into the intakes table
const AWS = require('aws-sdk');
const ddb = new AWS.DynamoDB.DocumentClient();

exports.handler = async (event) => {
  try {
    // event may be from API Gateway v2 (HTTP API) where body is in event.body
    const body = event.body ? JSON.parse(event.body) : (event || {});
    if (!body.patient_id && !body.intake_id) {
      return {
        statusCode: 400,
        body: JSON.stringify({ error: 'missing patient_id or intake_id' })
      };
    }

    const intakeId = body.intake_id || body.patient_id || `intake-${Date.now()}`;
    const item = {
      intake_id: String(intakeId),
      tenant_id: body.tenant_id || 'default-tenant',
      status: body.status || 'new',
      created_at: new Date().toISOString(),
      payload: body.payload || {}
    };

    const params = {
      TableName: process.env.INTAKES_TABLE,
      Item: item
    };

    await ddb.put(params).promise();

    return {
      statusCode: 201,
      body: JSON.stringify({ success: true, item })
    };
  } catch (err) {
    console.error('ERROR', err);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: err.message })
    };
  }
};
